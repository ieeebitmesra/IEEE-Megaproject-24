# blockchain elections

To run the project,
python main.py

Apart from main.py (containing the backend) and the static folder (containing the frontend html files), all other files are not required unless specifically needed for a particular task. They just have been kept to know the development history.

To install the dependencies,
pip install -r requirements.txt

PLEASE NOTE:
Put your private key and other details in .env file
